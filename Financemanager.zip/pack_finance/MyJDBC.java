package pack_finance;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class MyJDBC {
    public static void connectoDb() {
        try {
            /*
            Class.forName("com.mysql.cj.jdbc.Driver");

            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/empdb123?useTimezone=true&serverTimezone=UTC",
                    "root","sa123");

            PreparedStatement preparedStatement = con.prepareStatement("select * from logs");
            ResultSet rs = preparedStatement.executeQuery();


            if (rs.next() == true)
            {
                System.out.println("name is"+ rs.getString(1));
            }
            con.close();




        } catch (Exception ex) {
            ex.printStackTrace();



            connectToDb();
        }


        private void connectToDb()
        {
            try
            {
                Class.forName("com.mysql.cj.jdbc.Driver");

                con = DriverManager.getConnection
                        ("jdbc:mysql://localhost:3306/logs?useTimezone=true&serverTimezone=UTC",
                                "root","sa123");

            }
            catch (Exception ex)
            {
                ex.printStackTrace();
            }

             */

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}

