package pack_finance;

import com.toedter.calendar.JDateChooser;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.sql.*;
import java.text.SimpleDateFormat;

public class AddTransaction implements ActionListener {
    JFrame jFrame;
    JTextField amtField;
    JComboBox<String> typeField, categField;
    JDateChooser dateChooser;
    Connection con;
    private DashBoard dashBoard;

    public AddTransaction(int userId, DashBoard dashBoard) {
        this.dashBoard = dashBoard;
        con = connectDatabase();

        if (con == null) {
            JOptionPane.showMessageDialog(null, "Failed to connect to database.");
            return;
        }

        jFrame = new JFrame("Add Transaction");
        jFrame.setBounds(300, 50, 600, 700);
        jFrame.setLayout(null);
        jFrame.setIconImage(new ImageIcon("src/pack_finance/wallet.png").getImage());
        jFrame.getContentPane().setBackground(Color.white);
        jFrame.setResizable(false);


        JLabel dateLabel = new JLabel("Date:");
        dateLabel.setBounds(50, 65, 300, 120);
        dateLabel.setFont(new Font("Dialog", Font.BOLD, 30));

        JLabel typeLabel = new JLabel("Type:");
        typeLabel.setBounds(50, 155, 300, 120);
        typeLabel.setFont(new Font("Dialog", Font.BOLD, 30));

        JLabel categoryLabel = new JLabel("Category:");
        categoryLabel.setBounds(50, 265, 300, 120);
        categoryLabel.setFont(new Font("Dialog", Font.BOLD, 30));

        JLabel amountLabel = new JLabel("Amount:");
        amountLabel.setBounds(50, 385, 300, 120);
        amountLabel.setFont(new Font("Dialog", Font.BOLD, 30));

        dateChooser = new JDateChooser();
        dateChooser.setBounds(200, 110, 350, 33);

        String[] transactionTypes = {"Income", "Expense"};
        typeField = new JComboBox<>(transactionTypes);
        typeField.setBounds(200, 200, 350, 33);

        String[] categoryTypes = {"Salary", "Bills", "Food", "Insurance", "Clothing", "Home", "Transportation", "Education", "Others"};
        categField = new JComboBox<>(categoryTypes);
        categField.setBounds(200, 310, 350, 33);

        amtField = new JTextField();
        amtField.setBounds(200, 430, 350, 33);

        JButton saveButton = new JButton("Save");
        saveButton.setBounds(220, 510, 150, 60);
        saveButton.setBackground(Color.decode("#2E8B57"));
        saveButton.addActionListener(this);

        jFrame.add(dateLabel);
        jFrame.add(typeLabel);
        jFrame.add(categoryLabel);
        jFrame.add(amountLabel);
        jFrame.add(dateChooser);
        jFrame.add(typeField);
        jFrame.add(categField);
        jFrame.add(amtField);
        jFrame.add(saveButton);
        jFrame.setLocationRelativeTo(null);
        jFrame.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        try {
            registerTransaction();
        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(jFrame, "Error saving transaction: " + ex.getMessage());
        }
    }

    private Connection connectDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/maindata", "root", "sa123");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Database Connection Failed: " + ex.getMessage());
            return null;
        }
    }

    private void registerTransaction() throws SQLException {
        if (con == null) {
            JOptionPane.showMessageDialog(null, "Database connection is not working.");
            return;
        }

        if (dateChooser.getDate() == null) {
            JOptionPane.showMessageDialog(jFrame, "Please select a valid date", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String date = dateFormat.format(dateChooser.getDate());
        String type = (String) typeField.getSelectedItem();
        String category = (String) categField.getSelectedItem();
        String amountText = amtField.getText().trim();

        if (type == null || category == null || amountText.isEmpty()) {
            JOptionPane.showMessageDialog(jFrame, "All fields are required", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        BigDecimal amount;
        try {
            amount = new BigDecimal(amountText);
            if (amount.compareTo(BigDecimal.ZERO) <= 0) {
                JOptionPane.showMessageDialog(null, "Amount must be greater than 0");
                return;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid amount. Please enter a numeric value");
            return;
        }

        int userId = fetchUserId();
        if (userId <= 0) {
            JOptionPane.showMessageDialog(jFrame, "User not found. Cannot add transaction", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String query = "INSERT INTO TRANSCATION (date, type, category, amount, user_id) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement preparedStatement = con.prepareStatement(query)) {
            preparedStatement.setString(1, date);
            preparedStatement.setString(2, type);
            preparedStatement.setString(3, category);
            preparedStatement.setBigDecimal(4, amount);
            preparedStatement.setInt(5, userId);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Transaction Added Successfully");

                if (dashBoard != null) {
                    dashBoard.fetchData();
                } else {
                    JOptionPane.showMessageDialog(null, "Dashboard data not provided");
                }
            } else {
                JOptionPane.showMessageDialog(null, "Transaction Failed");
            }
        }
    }

    private int fetchUserId() {
        int userId = -1;
        try {
            String query = "SELECT user_id FROM INFO WHERE username = ?";
            try (PreparedStatement stmt = con.prepareStatement(query)) {
                stmt.setString(1, JOptionPane.showInputDialog("Enter Username:"));
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        userId = rs.getInt("user_id");
                    }
                }
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        }
        return userId;
    }
}