package pack_finance;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Signupform implements ActionListener {
    JFrame jFrame;
    JTextField usernameField, emailField;
    JPasswordField passField, confirmField;
    JButton signupButton;
    Image image;
    Connection con;
    PreparedStatement preparedStatement;

    public Signupform() {
        con = connectDatabase();


        //region frame
        jFrame = new JFrame();
        jFrame.setBounds(360, 80, 800, 700);
        jFrame.setTitle("Finance Manager");
        jFrame.setLayout(null);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLocationRelativeTo(null);
        jFrame.setResizable(false);
        jFrame.setIconImage(new ImageIcon("src/pack_finance/wallet.png").getImage());
        jFrame.getContentPane().setBackground(Color.white);
        //endregion

        //region label
        JLabel loginLabel = new JLabel("Registration");
        loginLabel.setBounds(100, 25, 520, 100);
        loginLabel.setFont(new Font("Dialog", Font.BOLD, 40));
        loginLabel.setHorizontalAlignment(SwingConstants.CENTER);
        loginLabel.setForeground(Color.WHITE);
        ImageIcon imageIcon = new ImageIcon("src/pack_finance/login.png");
        loginLabel.setIcon(imageIcon);
        loginLabel.setForeground(Color.BLACK);


        JLabel emailLabel = new JLabel("EMAIL :");
        emailLabel.setBounds(200, 150, 400, 25);
        emailLabel.setFont(new Font("Dialog", Font.BOLD, 18));
        emailLabel.setForeground(Color.BLACK);


        JLabel usernamelabel = new JLabel("USERNAME :");
        usernamelabel.setBounds(200, 220, 400, 25);
        usernamelabel.setFont(new Font("Dialog", Font.BOLD, 18));
        usernamelabel.setForeground(Color.BLACK);


        JLabel passwordLabel = new JLabel("PASSWORD :");
        passwordLabel.setBounds(200, 290, 400, 25);
        passwordLabel.setFont(new Font("Dialog", Font.BOLD, 18));
        passwordLabel.setForeground(Color.BLACK);


        JLabel confirmLabel = new JLabel("CONFIRM PASSWORD :");
        confirmLabel.setBounds(200, 360, 400, 25);
        confirmLabel.setFont(new Font("Dialog", Font.BOLD, 18));
        confirmLabel.setForeground(Color.BLACK);
        //endregion

        //region fields
        emailField = new JTextField();
        emailField.setBounds(190, 180, 350, 33);


        usernameField = new JTextField();
        usernameField.setBounds(190, 250, 350, 33);
        jFrame.add(usernameField);

        passField = new JPasswordField();
        passField.setBounds(190, 320, 350, 33);


        confirmField = new JPasswordField();
        confirmField.setBounds(190, 390, 350, 33);
        //endregion

        //region button
        signupButton = new JButton("SIGN UP");
        signupButton.setBounds(260, 450, 200, 40);
        signupButton.setFont(new Font("Arial", Font.BOLD, 14));
        signupButton.setForeground(Color.WHITE);
        signupButton.setBackground(Color.decode("#2E8B57"));
        signupButton.addActionListener(this);

        //endregion

        //region add
        jFrame.add(loginLabel);
        jFrame.add(emailLabel);
        jFrame.add(usernamelabel);
        jFrame.add(passwordLabel);
        jFrame.add(confirmLabel);
        jFrame.add(emailField);
        jFrame.add(passField);
        jFrame.add(confirmField);
        jFrame.add(signupButton);

        jFrame.setVisible(true);
        //endregion
    }



//region override
    @Override
    public void actionPerformed(ActionEvent e) {
        registerUser();

    }


    private Connection connectDatabase() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection("jdbc:mysql://localhost:3306/maindata", "root", "sa123");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "Database Connection Failed: " + ex);
            return null;
        }
    }

    //endregion


    //region register


    private void registerUser()
    {
        String email = emailField.getText();
        String username = usernameField.getText();
        String password = new String(passField.getPassword());
        String confirmPassword = new String(confirmField.getPassword());
        username = usernameField.getText().trim();
        password = new String(passField.getPassword()).trim();
        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(jFrame, "Both username and password are required", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }


        if (!password.equals(confirmPassword)) {
            JOptionPane.showMessageDialog(null, "Passwords  not match");
            return;
        }

        try {
            String query = "INSERT INTO INFO (username,password,user_email) VALUES (?, ?, ?)";
            preparedStatement = con.prepareStatement(query);
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, email);

            int rowsAffected = preparedStatement.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Registration Successful!");
                jFrame.dispose();
                new Loginpage();
            } else {
                JOptionPane.showMessageDialog(null, "Registration Failed!");
            }

        } catch (SQLException ex) {
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database Error: " + ex);
        }


    }

    //endregion

}