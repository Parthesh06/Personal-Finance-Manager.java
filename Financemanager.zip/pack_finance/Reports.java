package pack_finance;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import java.sql.*;
import java.awt.*;

public class Reports {
    JFrame jFrame;


    public Reports(int userId)
    {
        jFrame = new JFrame();
        jFrame.setBounds(300, 50, 700, 500);
        jFrame.setTitle("Reports");
        jFrame.setLayout(null);
        jFrame.setIconImage(new ImageIcon("src/pack_finance/wallet.png").getImage());
        jFrame.getContentPane().setBackground(Color.decode("#222831"));

        jFrame.setResizable(false);
        jFrame.getContentPane().setBackground(Color.decode("#E8F9FF"));
        jFrame.setLocationRelativeTo(null);
        jFrame.setVisible(true);


        JLabel generate = new JLabel("Generate");
        generate.setBounds(100, 8, 520, 100);
        generate.setFont(new Font("Dialog", Font.BOLD, 40));
        generate.setHorizontalAlignment(SwingConstants.CENTER);
        ImageIcon imageIcon = new ImageIcon("src/pack_finance/login.png");
        generate.setIcon(imageIcon);
        generate.setForeground(Color.BLACK);


        FinanceGraph financeGraph = new FinanceGraph();
        ChartPanel pieChartPanel = financeGraph.createPieChartPanel(userId);
        pieChartPanel.setBounds(50,100,600,350);
        jFrame.add(pieChartPanel);




        jFrame.add(generate);
        jFrame.add(pieChartPanel);
        jFrame.setVisible(true);

    }

    public class FinanceGraph {
        public ChartPanel createPieChartPanel(int userId) {
            DefaultPieDataset dataset = new DefaultPieDataset();

            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/maindata", "root", "sa123")) {
                String sql = "SELECT category, SUM(amount) AS total FROM TRANSCATION WHERE type = 'Expense' AND user_id = ? GROUP BY category";
                try (PreparedStatement stmt = con.prepareStatement(sql)) {
                    stmt.setInt(1, userId);
                    try (ResultSet rs = stmt.executeQuery()) {
                        while (rs.next()) {
                            dataset.setValue(rs.getString("category"), rs.getDouble("total"));
                        }
                    }
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }

            JFreeChart pieChart = ChartFactory.createPieChart(
                    "Expense by Category",
                    dataset,
                    true,
                    true,
                    false
            );

            return new ChartPanel(pieChart);
        }
    }

    }




