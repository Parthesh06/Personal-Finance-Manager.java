package pack_finance;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.category.DefaultCategoryDataset;

import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class DashBoard {
    JFrame jFrame;
    JLabel currentBalanceLabel, totalIncomeLabel, totalExpenseLabel;
    int userId;

    public DashBoard(int userId) {
        this.userId = userId;

        //region Frame

        jFrame = new JFrame();
        jFrame.setExtendedState(JFrame.MAXIMIZED_BOTH);
        jFrame.setTitle("Finance Manager");
        jFrame.setLayout(null);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLocationRelativeTo(null);
        jFrame.setResizable(false);
        jFrame.setIconImage(new ImageIcon("src/pack_finance/wallet.png").getImage());
        jFrame.getContentPane().setBackground(Color.white);

        //endregion

        //region panel
        JLabel label = new JLabel("Personal Finance Manager");
        label.setBounds(200, 1, 1020, 110);
        label.setFont(new Font("Dialog", Font.BOLD, 40));
        label.setIcon(new ImageIcon("src/pack_finance/wallet.png"));
        label.setHorizontalAlignment(SwingConstants.CENTER);
        label.setForeground(Color.BLACK);

        totalIncomeLabel = new JLabel("Total Income: Loading...");
        totalExpenseLabel = new JLabel("Total Expense: Loading...");
        currentBalanceLabel = new JLabel("Current Balance: Loading...");

        totalIncomeLabel.setFont(new Font("Dialog", Font.BOLD, 30));
        totalExpenseLabel.setFont(new Font("Dialog", Font.BOLD, 30));
        currentBalanceLabel.setFont(new Font("Dialog", Font.BOLD, 30));

        totalIncomeLabel.setForeground(Color.white);
        totalExpenseLabel.setForeground(Color.white);
        currentBalanceLabel.setForeground(Color.white);

        JPanel panelContainer1 = new JPanel();
        panelContainer1.setBounds(90, 150, 400, 200);
        panelContainer1.setBackground(Color.decode("#2E8B57"));
        panelContainer1.add(currentBalanceLabel);

        JPanel panelContainer2 = new JPanel();
        panelContainer2.setBounds(550, 150, 400, 200);
        panelContainer2.setBackground(Color.decode("#2E8B57"));
        panelContainer2.add(totalIncomeLabel);

        JPanel panelContainer3 = new JPanel();
        panelContainer3.setBounds(1020, 150, 400, 200);
        panelContainer3.setBackground(Color.decode("#2E8B57"));
        panelContainer3.add(totalExpenseLabel);

        //endregion

        //region buttons
        JButton addTransaction = new JButton("ADD TRANSACTION");
        addTransaction.setBounds(1310, 410, 200, 60);
        addTransaction.setFont(new Font("Arial", Font.BOLD, 14));
        addTransaction.setBackground(Color.decode("#2E8B57"));
        addTransaction.setForeground(Color.white);
        addTransaction.setFocusable(false);
        addTransaction.addActionListener(e -> {
            new AddTransaction(userId, this);
            fetchData();
        });

        JButton viewReport = new JButton("VIEW REPORTS");
        viewReport.setBounds(1310, 510, 200, 60);
        viewReport.setFont(new Font("Arial", Font.BOLD, 14));
        viewReport.setBackground(Color.decode("#2E8B57"));
        viewReport.setForeground(Color.white);
        viewReport.setFocusable(false);
        viewReport.addActionListener(e -> new Reports(userId));

        JButton budgetPlanning = new JButton("BUDGET PLANNING");
        budgetPlanning.setBounds(1310, 610, 200, 60);
        budgetPlanning.setFont(new Font("Arial", Font.BOLD, 14));
        budgetPlanning.setBackground(Color.decode("#2E8B57"));
        budgetPlanning.setForeground(Color.white);;
        budgetPlanning.setFocusable(false);

/*
        JButton refreshButton = new JButton("REFRESH DATA");
        refreshButton.setBounds(1310, 710, 200, 60);
        refreshButton.setFont(new Font("Arial", Font.BOLD, 14));
        refreshButton.setBackground(Color.decode("#2E8B57"));
        refreshButton.setFocusable(false);
        refreshButton.addActionListener(e -> fetchData());


 */

        //endregion

        FinanceGraph financeGraph = new FinanceGraph();
        ChartPanel chartPanel = financeGraph.createChartPanel(userId);
        chartPanel.setBounds(90, 400, 1000, 420);



        jFrame.add(label);
        jFrame.add(panelContainer1);
        jFrame.add(panelContainer2);
        jFrame.add(panelContainer3);
        jFrame.add(addTransaction);
        jFrame.add(viewReport);
        jFrame.add(budgetPlanning);
        jFrame.add(chartPanel);
        jFrame.setVisible(true);


        fetchData();
    }
//region connection
    public void fetchData() {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/maindata", "root", "sa123")) {

            String sqlIncome = "SELECT COALESCE(SUM(amount), 0) AS total_income FROM TRANSCATION WHERE type = 'Income' AND user_id = ?";
            try (PreparedStatement stmtIncome = con.prepareStatement(sqlIncome)) {
                stmtIncome.setInt(1, userId);
                try (ResultSet rsIncome = stmtIncome.executeQuery()) {
                    if (rsIncome.next()) {
                        totalIncomeLabel.setText("Total Income: ₹" + rsIncome.getDouble("total_income"));
                    }
                }
            }


            String sqlExpense = "SELECT COALESCE(SUM(amount), 0) AS total_expense FROM TRANSCATION WHERE type = 'Expense' AND user_id = ?";
            try (PreparedStatement stmtExpense = con.prepareStatement(sqlExpense)) {
                stmtExpense.setInt(1, userId);
                try (ResultSet rsExpense = stmtExpense.executeQuery()) {
                    if (rsExpense.next()) {
                        totalExpenseLabel.setText("Total Expense: ₹" + rsExpense.getDouble("total_expense"));
                    }
                }
            }

            String sqlBalance = "SELECT COALESCE(SUM(CASE WHEN type = 'Income' THEN amount ELSE -amount END), 0) AS current_balance FROM TRANSCATION WHERE user_id = ?";
            try (PreparedStatement stmtBalance = con.prepareStatement(sqlBalance)) {
                stmtBalance.setInt(1, userId);
                try (ResultSet rsBalance = stmtBalance.executeQuery()) {
                    if (rsBalance.next()) {
                        currentBalanceLabel.setText("Current Balance: ₹" + rsBalance.getDouble("current_balance"));
                    }
                }
            }
            jFrame.revalidate();
            jFrame.repaint();


        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Error fetching financial data: " + e.getMessage());
        }
    }
}
//endregion
class FinanceGraph {
    public ChartPanel createChartPanel(int userId) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/maindata", "root", "sa123")) {
            String sql = "SELECT type, category, SUM(amount) AS total FROM TRANSCATION WHERE user_id = ? GROUP BY type, category";
            try (PreparedStatement stmt = con.prepareStatement(sql)) {
                stmt.setInt(1, userId);
                try (ResultSet rs = stmt.executeQuery()) {
                    while (rs.next()) {
                        dataset.addValue(rs.getDouble("total"), rs.getString("category"), "category");
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        JFreeChart barChart = ChartFactory.createBarChart(
                "Spending Overview",
                "Category",
                "Amount",
                dataset
        );

        return new ChartPanel(barChart);
    }
}

