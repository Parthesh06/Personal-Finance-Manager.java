package pack_finance;
import javax.swing.*;
import java.sql.*;

import java.sql.Connection;

public class Sqlconnection {

    public static Connection connectdb(){
        String sqluseername ="root";
        String sqlpassword = "sa123";
        String dburl = "jdbc:mysql://localhost:3306/logs?useTimezone=true&serverTimezone=UTC";
        try{

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(dburl,sqluseername,sqlpassword);
            return  con;



        } catch (SQLException|ClassNotFoundException e) {
            JOptionPane.showMessageDialog(null,e);
        }

        return null;
    }
}
