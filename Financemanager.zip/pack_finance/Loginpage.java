package pack_finance;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Loginpage implements ActionListener {
    JFrame jFrame;
    JTextField usernameField;
    JPasswordField passwordFields;
    Connection con;
    Font font;

    public Loginpage() {

//region frame
        jFrame = new JFrame();
        jFrame.setBounds(360, 80, 800, 700);
        jFrame.setTitle("Finance Manager");
        jFrame.setLayout(null);
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setLocationRelativeTo(null);
        jFrame.setResizable(false);
        jFrame.setIconImage(new ImageIcon("src/pack_finance/wallet.png").getImage());
        jFrame.getContentPane().setBackground(Color.WHITE);
//endregion

//region label
        JLabel loginlabel = new JLabel("Login");
        loginlabel.setBounds(100, 25, 520, 100);
        loginlabel.setFont(new Font("Dialog", Font.BOLD, 40));
        loginlabel.setHorizontalAlignment(SwingConstants.CENTER);
        ImageIcon imageIcon = new ImageIcon("src/pack_finance/login.png");
        loginlabel.setIcon(imageIcon);
        loginlabel.setForeground(Color.BLACK);
        jFrame.add(loginlabel);


        JLabel usernamelabel = new JLabel("USERNAME :");
        usernamelabel.setBounds(50, 150, 400, 25);
        usernamelabel.setFont(new Font("Arial", Font.BOLD, 18));
        usernamelabel.setHorizontalAlignment(SwingConstants.CENTER);
        usernamelabel.setForeground(Color.BLACK);


        JLabel passwordlabel = new JLabel("PASSWORD :");
        passwordlabel.setBounds(50, 230, 400, 25);
        passwordlabel.setFont(new Font("Dialog", Font.BOLD, 18));
        passwordlabel.setHorizontalAlignment(SwingConstants.CENTER);
        passwordlabel.setForeground(Color.BLACK);

        JLabel orname = new JLabel("------------OR------------");
        orname.setBounds(270, 340, 500, 100);
        orname.setFont(new Font("Dialog", Font.BOLD, 18));
        orname.setForeground(Color.BLACK);

        JLabel name = new JLabel("Don't Have an account ?");
        name.setBounds(260, 380, 500, 100);
        name.setFont(new Font("Dialog", Font.BOLD, 18));
        name.setForeground(Color.BLACK);
//endregion

//region textfield
        this.usernameField = new JTextField();
        usernameField.setBounds(190, 185, 350, 33);
        usernameField.setFont(new Font("Dialog", Font.PLAIN, 18));


        this.passwordFields = new JPasswordField();
        passwordFields.setBounds(190, 265, 350, 33);
        passwordFields.setFont(new Font("Dialog", Font.PLAIN, 18));
//endregion

//region button
        JButton login = new JButton("Login");
        login.setBounds(260, 320, 200, 30);
        login.setFont(new Font("Arial", Font.BOLD, 14));
        login.setForeground(Color.WHITE);
        login.setBackground(Color.decode("#2E8B57"));


        JButton singup = new JButton("Signup");
        singup.setBounds(260, 460, 200, 30);
        singup.setFont(new Font("Arial", Font.BOLD, 14));
        singup.setForeground(Color.WHITE);
        singup.setBackground(Color.decode("#2E8B57"));
        singup.addActionListener(e -> {
            new Signupform().jFrame.setVisible(true);
        });
//endregion

//region add
        jFrame.setLocationRelativeTo(null);
        jFrame.add(loginlabel);
        jFrame.add(usernamelabel);
        jFrame.add(usernameField);
        jFrame.add(passwordlabel);
        jFrame.add(passwordFields);
        jFrame.add(orname);
        jFrame.add(name);
        jFrame.add(login);
        jFrame.add(singup);
        jFrame.setVisible(true);
        login.addActionListener(this);

//endregion
    }
//region connection
    @Override
    public void actionPerformed(ActionEvent e) {
        String username = usernameField.getText().trim();
        String password = String.valueOf(passwordFields.getPassword()).trim();

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(jFrame, "Both username and password are required.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/maindata", "root", "sa123")) {
            String sqlQuery = "SELECT user_id FROM INFO WHERE username = ? AND password = ?";
            try (PreparedStatement pst = con.prepareStatement(sqlQuery)) {
                pst.setString(1, username);
                pst.setString(2, password);
                try (ResultSet rs = pst.executeQuery()) {
                    if (rs.next()) {
                        int userId = rs.getInt("user_id");
                        JOptionPane.showMessageDialog(jFrame, "Login Successful!");
                        jFrame.dispose();
                        new DashBoard(userId);
                    } else {
                        JOptionPane.showMessageDialog(null, "INVALID LOGIN", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Database Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
//endregion